import { Component, OnInit } from '@angular/core'
import { RouterExtensions } from '@nativescript/angular'

interface MarketPrice {
  product: string
  currentPrice: number
  unit: string
  trend: 'up' | 'down' | 'stable'
}

@Component({
  selector: 'ns-market-prices',
  templateUrl: './market-prices.component.html',
})
export class MarketPricesComponent implements OnInit {
  marketPrices: Array<MarketPrice> = [
    { product: 'Tomatoes', currentPrice: 2.8, unit: 'kg', trend: 'up' },
    { product: 'Potatoes', currentPrice: 1.5, unit: 'kg', trend: 'down' },
    { product: 'Carrots', currentPrice: 1.2, unit: 'kg', trend: 'stable' },
    { product: 'Apples', currentPrice: 3.2, unit: 'kg', trend: 'up' },
    { product: 'Lettuce', currentPrice: 1.7, unit: 'head', trend: 'up' },
  ]

  constructor(private routerExtensions: RouterExtensions) {}

  ngOnInit(): void {}

  goBack(): void {
    this.routerExtensions.back()
  }

  getTrendClass(trend: string): string {
    switch (trend) {
      case 'up':
        return 'text-green-500'
      case 'down':
        return 'text-red-500'
      default:
        return 'text-gray-500'
    }
  }
}