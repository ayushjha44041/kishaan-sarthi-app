import { Injectable } from '@angular/core'

import { Product } from './product'

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  private products = new Array<Product>(
    { id: 1, name: 'Tomatoes', quantity: 100, unit: 'kg', price: 2.5 },
    { id: 2, name: 'Potatoes', quantity: 200, unit: 'kg', price: 1.8 },
    { id: 3, name: 'Carrots', quantity: 150, unit: 'kg', price: 1.2 },
    { id: 4, name: 'Apples', quantity: 80, unit: 'kg', price: 3.0 },
    { id: 5, name: 'Lettuce', quantity: 50, unit: 'heads', price: 1.5 }
  )

  getProducts(): Array<Product> {
    return this.products
  }

  getProduct(id: number): Product {
    return this.products.filter((product) => product.id === id)[0]
  }
}