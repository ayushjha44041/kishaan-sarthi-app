export interface Product {
  id: number
  name: string
  quantity: number
  unit: string
  price: number
}