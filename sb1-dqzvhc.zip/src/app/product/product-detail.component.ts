import { Component, OnInit } from '@angular/core'
import { ActivatedRoute } from '@angular/router'
import { RouterExtensions } from '@nativescript/angular'
import { alert, prompt } from '@nativescript/core'

import { Product } from './product'
import { ProductService } from './product.service'

@Component({
  selector: 'ns-product-detail',
  templateUrl: './product-detail.component.html',
})
export class ProductDetailComponent implements OnInit {
  product: Product

  constructor(
    private productService: ProductService,
    private route: ActivatedRoute,
    private routerExtensions: RouterExtensions
  ) {}

  ngOnInit(): void {
    const id = +this.route.snapshot.params.id
    this.product = this.productService.getProduct(id)
  }

  goBack(): void {
    this.routerExtensions.back()
  }

  updatePrice(): void {
    prompt({
      title: 'Update Price',
      message: 'Enter the new price:',
      inputType: 'decimal',
      defaultText: this.product.price.toString(),
      okButtonText: 'Update',
      cancelButtonText: 'Cancel'
    }).then(result => {
      if (result.result) {
        const newPrice = parseFloat(result.text)
        if (!isNaN(newPrice) && newPrice > 0) {
          this.product.price = newPrice
          alert({
            title: 'Price Updated',
            message: `The price for ${this.product.name} has been updated to $${newPrice.toFixed(2)}/${this.product.unit}.`,
            okButtonText: 'OK'
          })
        } else {
          alert({
            title: 'Invalid Price',
            message: 'Please enter a valid price greater than 0.',
            okButtonText: 'OK'
          })
        }
      }
    })
  }
}