import { Component, OnInit } from '@angular/core'
import { RouterExtensions } from '@nativescript/angular'

import { Product } from './product'
import { ProductService } from './product.service'

@Component({
  selector: 'ns-product-list',
  templateUrl: './product-list.component.html',
})
export class ProductListComponent implements OnInit {
  products: Array<Product>

  constructor(
    private productService: ProductService,
    private routerExtensions: RouterExtensions
  ) {}

  ngOnInit(): void {
    this.products = this.productService.getProducts()
  }

  goToMarketPrices(): void {
    this.routerExtensions.navigate(['/market-prices'])
  }
}